#!/bin/bash

for i in $(find ../sessions/ -type d -mtime +1); do
       rm -fr $i
done
