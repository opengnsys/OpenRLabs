#!/bin/bash

python3 /var/www/web2py/web2py.py -S rlabs -M -R applications/rlabs/modules/bg_check_prereserves.py
