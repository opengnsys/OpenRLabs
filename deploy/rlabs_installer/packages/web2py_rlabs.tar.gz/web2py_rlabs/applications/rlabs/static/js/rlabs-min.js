xhr=new XMLHttpRequest();function requestAJAX(url,parametros,callbackFunction){xhr.open("POST",url,true);xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');document.getElementById("table_ous").setAttribute("style","cursor:progress;");document.body.setAttribute("style","cursor:progress;");xhr.send(parametros);xhr.onreadystatechange=function(){if(xhr.readyState==4&&xhr.status==200){var respuesta=JSON.parse(xhr.responseText);document.getElementById("table_ous").setAttribute("style","cursor:pointer;");document.body.style.cursor="pointer";if(respuesta.error===undefined){callbackFunction(respuesta);}else{alert(respuesta.error);refresh_page();}}}}
function insert_disponibles_before_pcs(disponibles_info){var table=document.getElementById("table_lab_"+disponibles_info.lab_id);var new_row=table.insertRow();new_row.setAttribute("style","display:block;");new_row.setAttribute("id","disponibles_before_pcs_lab_"+disponibles_info.lab_id);new_row.setAttribute("class","disponible");var new_cell=new_row.insertCell();new_cell.innerHTML=disponibles_info.disponibles+" de "+disponibles_info.total+" equipos disponibles";}
function delete_disponibles(){delete_by_class('disponible');}
function delete_disponible_before_images(lab_id){document.getElementById("disponibles_before_images_lab_"+lab_id).remove();}
function hide_footer(){var footers=document.getElementsByClassName('footer');footers[0].style.display='none';}
function show_footer(){var footers=document.getElementsByClassName('footer');footers[0].style.display='block';}
function show_Labs(labs){delete_labs();labs.forEach(show_Lab);}
function delete_labs(){delete_by_class('lab');}
function show_Lab(lab,index){delete_disponibles();var table=document.getElementById("table_ou_"+lab.ou.id);table.setAttribute("style","background:NONE;");var new_row=table.insertRow();new_row.setAttribute("id","lab_"+lab.id);new_row.setAttribute("class","lab");new_row.setAttribute("style","display:block;");var htmlRow="<td width='16'>"+
"<img src='../static/images/aula.png' "+
"data-ou='"+lab.ou.id+"' "+
"data-lab_id='"+lab.id+"' onClick='get_remotePCs(event)'>"+
"</td>"+
"<td>"+
"<table id='table_lab_"+lab.id+"'>"+
"<tbody>"+
"<tr>"+
"<td>"+
"<span class='labs' "+
"data-ou='"+lab.ou.id+"' "+
"data-lab_id='"+lab.id+"' onClick='get_remotePCs(event)'>"+
lab.name+"</span>"+
"</td>"+
"</tr>"
if(typeof(lab.status)!=='undefined'){console.log(lab);htmlRow=htmlRow+"<tr>"+
"<td>"+
"<span id='disponibles_before_images_lab_"+lab.id+"' class='disponible' "+
"data-ou='"+lab.ou.id+"' "+
"data-lab_id='"+lab.id+"' onClick='get_remotePCs(event)'>   "+
lab.status.clients_disponibles+" de "+lab.status.clients_total+" equipos disponibles</span>"+
"</td>"+
"</tr>"}
htmlRow=htmlRow+"</tbody>"+"</table>"+"</td>"
new_row.innerHTML=htmlRow;}
function reset_modal(){document.getElementById("text_consolelog").value='';document.getElementById("buttonConsole").style.display='none';reset_progress_bar();delete_pcs();delete_images();delete_disponibles();}
function show_images(image,index){img=getImg_sys(image.os);var table=document.getElementById("table_lab_"+image.lab_id);var new_row=table.insertRow();new_row.setAttribute("class","image");var new_cell=new_row.insertCell();new_cell.setAttribute("style","text-align: right;");new_cell.innerHTML="<img class='status_equipo' height='30px' src='../static/images/"+img+"' "+
"data-lab_id='"+image.lab_id+"'>"
new_cell=new_row.insertCell();new_cell.innerHTML="<span> "+image.os+" </span>"
new_cell=new_row.insertCell();new_cell.innerHTML="<span><button type='button' class='btn btn-outline-secondary'"+
"onClick='do_assign_reserve(event)'"+
"data-ou_id='"+image.ou_id+"'"+
"data-image_id='"+image.id+"'"+
"data-lab_id='"+image.lab_id+"'"+
">Reservar</button></span>"}
function delete_images(){delete_by_class('image');}
function getImg_sys(sys){var os=sys.split(" ")[0];var img;switch(os){case 'Windows':img='windows.png'
break;case 'OSX':img='osx.png'
break;default:img='tux.png'
break;}
return img;}
function show_PCs(PCs){reset_style_table_lab(PCs.images_info[0].lab_id)
delete_pcs();delete_images();delete_spaces();hide_footer();PCs.images_info.forEach(show_images);if(PCs.images_info[0]!==undefined){insert_space_table_lab(PCs.images_info[0].lab_id);}
PCs.PCs_info.forEach(show_PC);cursor_wait('pointer');table_lab=document.getElementById('lab_'+PCs.images_info[0].lab_id);table_lab.setAttribute("style","background : white;display:block;");;}
function reset_style_table_lab(table_lab_id){table_lab=document.getElementById('lab_'+table_lab_id);table_lab.setAttribute("style","background : white;display:block;cursor:pointer");}
function show_PC(PC,index){var img=getImg_pc(PC.pc.status);var table=document.getElementById("table_lab_"+PC.pc.lab.id);var new_row=table.insertRow();new_row.setAttribute("id","pc_"+PC.pc.id);new_row.setAttribute("style","display:block;");new_row.setAttribute("class","pc");var new_cell=new_row.insertCell();new_cell.innerHTML="<img class='status_equipo' src='../static/images/"+img+"' "+
"data-id='"+PC.pc.id+
"'>"
new_cell=new_row.insertCell();new_cell.innerHTML="<table id='table_PCs' class='nivel2 table_PCs'>"+
"<tr id='PC_"+PC.pc.id+"'>"+
"<td>"+
"<span data-id='"+PC.pc.id+
"'> "+
PC.pc.name+"</span>"+
"</td>"+
"</tr>"+
"<tr>"+
"<table id='table_partitions_"+PC.pc.id+"' class='nivel3 partitions_table'>"+
"</tr>"+
"</table>"}
function delete_pcs(){delete_by_class('pc');}
function insert_space_table_lab(lab_id){var table=document.getElementById("table_lab_"+lab_id);var new_row=table.insertRow();new_row.setAttribute("class","space");var new_cell=new_row.insertCell();new_cell.innerHTML="<span>&nbsp;</span>"}
function delete_spaces(){delete_by_class('space');}
function getImg_pc(status){var img;if((typeof(status.status)==="undefined")){img='odernador_OFF.png'}else{switch(status.status){case 'off':img="odernador_OFF.png"
break;case 'WIN':case 'windows':if(('loggedin'in status)&&(status.loggedin==true)){img='odernador_WINS.png'}else{img='odernador_WIN.png'}
break;case 'LNX':case 'linux':if(('loggedin'in status)&&(status.loggedin==true)){img='odernador_LINS.png'}else{img='odernador_LIN.png'}
break;case 'OSX':img="odernador_OSX.png"
break;case 'oglive':img="odernador_OPG.png"
break;case 'busy':img="odernador_BSY.png"
break;default:img="odernador_OSX.png";}}
return img;}
function hide_progress_bar(animator){var progress_bar_container=document.getElementById("progress_bar_container");progress_bar_container.style.display='none';clearInterval(animator);document.getElementById("progress_bar").setAttribute("value","0");document.getElementById("progress_value").innerHTML="0%";}
function show__progress_bar(){var progress_bar=document.getElementById("progress_bar_container");progress_bar.style.display='block';var data_time=parseInt(document.getElementById('progress_bar').getAttribute('data-time'));var time=data_time*10
var progressbar=$('#progress_bar'),max=progressbar.attr('max'),time=time,value=progressbar.val();var loading=function(){value+=1;addValue=progressbar.val(value);$('.progress_value').html(value+'%');if(value==max){clearInterval(animate);}};var animate=setInterval(function(){loading();},time);return animate;}
function stop_progress_bar(){clearInterval(animator);document.getElementById("progress_bar").setAttribute("value","100");}
function reset_progress_bar(){clearInterval(animator);document.getElementById("progress_bar").setAttribute("value","0");document.getElementById("progress_value").innerHTML="0%";}
class TrReserves{constructor(reserve,table){this.table=table;this.tr='	<tr class="active_reserves_tr"></tr>';this.reserve=reserve;}
td1_html(){let html='<img id="img_connect_reserve_'+this.reserve['id']+'" '+
'class="status_equipo active_reserve_status" data-status="'+this.reserve['status']+'" '+
'data-loggedin="'+this.reserve['loggedin']+'" '+
'src="../static/images/odernador_WIN.png"></img>';return html}
td2_html(){let html='<span>'+this.reserve['pc_name']+'</span>';return html}
td3_html(){let html='<span><img class="image_user" src="../static/images/user.png"></span>';return html}
td4_html(){let html='<span>'+this.reserve['user_id']+'</span>';return html}
td5_html(){let html='<span><button id="btn_connect_reserve_'+this.reserve['id']+'" '+
'type="button" class="btn btn-secondary btn-client-connect" '+
'onclick="connect_remotePC(event)" '+
'data-reserve_id="'+this.reserve['id']+'" '+
'data-sound="on" '+
'data-pc_id="'+this.reserve['pc_id']+'" '+
'data-lab_id="'+this.reserve['lab_id']+'" '+
'data-ou_id="'+this.reserve['ou_id']+'" '+
'data-pc_name="'+this.reserve['pc_name']+'" '+
'data-port="'+this.reserve['port']+'" '+
'data-protocol="'+this.reserve['protocol']+'" '+
'data-ip="'+this.reserve['ip']+'">Conectar</button></span>'+
'<span><button type="button" class="btn btn-primary" '+
'onclick="unreserve(event)" '+
'data-reserve_id="'+this.reserve['id']+'" '+
'data-pc_id="'+this.reserve['pc_id']+'" '+
'data-lab_id="'+this.reserve['lab_id']+'" '+
'data-ou_id="'+this.reserve['ou_id']+'">Cancelar</button></span>'
return html}
insert_tr(){let tbody=this.table.getElementsByTagName('tbody')[0]
let row=tbody.insertRow();row.setAttribute("class","active_reserves_tr");let td1=row.insertCell();let td2=row.insertCell();let td3=row.insertCell();let td4=row.insertCell();let td5=row.insertCell();td1.innerHTML=this.td1_html();td2.innerHTML=this.td2_html();td3.innerHTML=this.td3_html();td4.innerHTML=this.td4_html();td5.innerHTML=this.td5_html();}}
class ReservesObserver{constructor(url_reserves,url_status,table){this.AWAIT_TIME_MS=10000;this.url=url_reserves;this.table=table;this.statusObserver=new StatusObserver(url_status);this.reserves=null;this.xhr=new XMLHttpRequest();this.interval=null;}
clear_table_reserves(){delete_by_class('active_reserves_tr');}
populate_table_reserves(){if(this.reserves!==null){for(i=0;i<this.reserves.length;i++){let reserve=new TrReserves(this.reserves[i],this.table);reserve.insert_tr()}}}
set_status_clients(){this.statusObserver.set_clients(document.getElementsByClassName('btn-client-connect'))
this.statusObserver.check_status_clients();}
set_reserves(){this.xhr.open("POST",this.url,true);this.xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');this.xhr.send();this.xhr.onreadystatechange=()=>{this.xhr.onreadystatechange=()=>{if(this.xhr.readyState==4&&this.xhr.status==200){this.reserves=JSON.parse(this.xhr.responseText);this.clear_table_reserves();this.populate_table_reserves();this.set_status_clients();}}}}
run(){this.set_reserves()
this.interval=setInterval(this.set_reserves.bind(this),this.AWAIT_TIME_MS);}
stop(){clearInterval(this.interval);}}
class StatusObserver{constructor(url){this.AWAIT_TIME_MS=10000;this.url=url
this.clients_to_connect_html=null;this.data_clients={}
this.xhr=new XMLHttpRequest();this.interval=null;}
set_clients(clients){this.clients_to_connect_html=clients;}
set_status_img_client(reserve_id,respuesta){document.getElementById("img_connect_reserve_"+
reserve_id).setAttribute('src',"../static/images/"+getImg_pc(respuesta[reserve_id]));}
set_status_img_clients(respuesta){for(i=0;i<this.clients_to_connect_html.length;i++){let reserve_id=this.clients_to_connect_html[i]['id'].split('_')[3]
this.set_status_img_client(reserve_id,respuesta);}}
do_request(){this.xhr.open("POST",this.url,true);this.xhr.setRequestHeader("Content-Type","application/json;charset=UTF-8");this.xhr.send(JSON.stringify(this.data_clients));this.xhr.onreadystatechange=()=>{this.xhr.onreadystatechange=()=>{if(this.xhr.readyState==4&&this.xhr.status==200){var respuesta=JSON.parse(this.xhr.responseText);this.set_status_img_clients(respuesta);}}}}
check_status_clients(){for(i=0;i<this.clients_to_connect_html.length;i++){this.data_clients[this.clients_to_connect_html[i].getAttribute('data-ip')]=this.clients_to_connect_html[i].getAttribute('data-reserve_id');}
this.do_request();}}
function delete_by_class(class_name){var class_items=document.getElementsByClassName(class_name);for(i=class_items.length-1;i>-1;i--){class_items[i].remove();}}
function hide_by_class(class_name){var class_items=document.getElementsByClassName(class_name);for(i=0;i<class_items.length-1;i++){class_items[i].style.display='none';}}