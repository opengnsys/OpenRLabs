
function hide_footer(){
	var footers = document.getElementsByClassName('footer');	
	footers[0].style.display = 'none';
	
}

function show_footer(){
	var footers = document.getElementsByClassName('footer');	
	footers[0].style.display = 'block';
	
}
