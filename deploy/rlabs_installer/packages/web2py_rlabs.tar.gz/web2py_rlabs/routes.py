routers = dict(
	BASE=dict(
		default_application='rlabs',
	)
)
